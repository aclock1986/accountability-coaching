# Accountability Coaching App — Setup Guide

Your coaching app is built and ready. It just needs to be connected to three
free services before clients can use it. Total cost: **$0**. Total time: about
**30 minutes**.

You will do this once. After that, clients sign up and the app runs itself.

---

## What you are setting up (plain English)

1. **Supabase** — the filing cabinet. Stores client accounts, check-ins,
   scorecards, and buddy chat history. Free tier.
2. **Google AI Studio** — the brain for the 24/7 AI buddy. Free tier,
   plenty for your first clients.
3. **Vercel** — the building the app lives in. Hosts the app and the buddy
   for free. Your app will live at an address like
   `accountability-coaching.vercel.app` until you add your own domain later.

---

## Part 1 — Supabase (about 10 minutes)

1. Go to **https://supabase.com** and click **Start your project**. Sign up
   with your Google account.
2. Click **New project**. Name it `accountability-coaching`. It will suggest
   a database password — save it somewhere safe (a note on your phone is fine).
   Pick the region closest to you. Click **Create new project** and wait a
   minute while it builds.
3. In the left sidebar, click the **SQL Editor** icon, then **New query**.
4. Open the file `supabase/schema.sql` from this project on your computer.
   Copy ALL of it, paste it into the SQL Editor, and click **Run**.
   You should see "Success. No rows returned." That created all four tables
   with the privacy rules (clients can only ever see their own data).
5. Now get your two keys. In the left sidebar click **Project Settings**
   (the gear icon), then **API**.
   - Copy the **Project URL** — looks like `https://xyzcompany.supabase.co`
   - Copy the **anon public** key (long string starting with `eyJ...`).
     Use the **anon** key, NOT the service_role key.
6. Keep those two somewhere — you will paste them into Vercel in Part 3.

**Cost: $0** (free tier covers far more clients than you will have at first).

## Part 2 — Google AI Studio key for the buddy (about 5 minutes)

1. Go to **https://aistudio.google.com** and sign in with your Google account.
2. Click **Get API key** (top left), then **Create API key**.
3. Copy the key. New keys start with `AQ.` (Google changed the format in May 2026 — older ones start with `AIza...`). Keep it private — never post it
   anywhere or send it to a client.
4. Keep it somewhere — you will paste it into Vercel in Part 3.

**Cost: $0** (free tier covers daily buddy chats for your first clients).

## Part 3 — Vercel deploy (about 15 minutes)

1. Put this project folder on GitHub:
   - Go to **https://github.com**, sign up, click **New repository**,
     name it `accountability-coaching`, and follow the "upload existing
     files" option to upload this whole folder.
2. Go to **https://vercel.com** and sign up with your GitHub account.
3. Click **Add New... → Project**, pick the `accountability-coaching`
   repository, and click **Import**.
4. Before you click Deploy, open the **Environment Variables** section and
   add these five (paste the values you saved):
   - `SUPABASE_URL` = your Project URL from Part 1, step 6
   - `SUPABASE_ANON_KEY` = your anon key from Part 1, step 6
   - `GEMINI_API_KEY` = your key from Part 2, step 3
   - `COACH_PHONE` = your phone number in international format,
     e.g. `+19105550123` (used by the "Send to Lee" button)
   - `COACH_NAME` = `Lee`
5. Click **Deploy**. Wait about a minute. Vercel will give you your app's
   address (something like `accountability-coaching.vercel.app`).

**Cost: $0.**

## Part 4 — Test it (5 minutes)

1. Open your new app address on your phone.
2. Create an account with a test email.
3. Walk through the onboarding (name, lane, one goal).
4. Submit a check-in. Open the Buddy and send it a message.
5. Tap **Send my update to Lee** and confirm the text looks right.
6. Optional: delete the test client row later in Supabase
   (Table Editor → `clients` → delete the test row).

---

## How clients use it

1. You onboard each client as you do now (intake, lane, one goal).
2. Send them the app address. They create their account and complete the
   short onboarding in the app.
3. They check in **daily, Monday through Friday**.
   - **Monday and Friday:** they text Lee directly — Monday sets the week's
     plan, Friday wraps the week. Then they tap **"I texted Lee"** in the app
     to confirm. Friday's confirmation builds their Weekly Win Scorecard.
   - **Tuesday, Wednesday, Thursday:** quick check-in forms in the app.
   - **Saturday and Sunday:** off. No check-ins expected, never marked missed.
4. Missed days show as **X**. No chasing — the app just stays honest.
5. They can talk to the AI buddy any time, free with coaching.
6. They tap **Send my update to Lee** and it texts you their week.

## If something breaks

- **App shows "Almost ready"**: the Vercel environment variables are missing
  or misspelled. Go to Vercel → your project → Settings → Environment
  Variables, fix them, then Redeploy.
- **Buddy says "not configured"**: the `GEMINI_API_KEY` variable is missing
  in Vercel. Add it and redeploy.
- **Can't sign up**: check the Supabase SQL ran successfully (Part 1, step 4).
- **"Send to Lee" doesn't text**: the `COACH_PHONE` variable needs your
  number in `+1` international format.

## Later, when it earns

- Add your own domain in Vercel (domain itself costs ~$12/year).
- If free-tier limits ever pinch, that means you have paying clients —
  the paid tiers pay for themselves.

---

## Files in this project

- `index.html` / `styles.css` / `app.js` — the app itself
- `api/chat.js` — the AI buddy (runs on Vercel, key stays server-side)
- `supabase/schema.sql` — database tables + privacy rules
- `config.example.js` — what the app's settings look like
  (real `config.js` is generated automatically at deploy — never edit by hand)
- `scripts/build-config.js` — generates `config.js` from Vercel variables
- `vercel.json` / `package.json` — deploy configuration
