/**
 * POST /api/chat — the 24/7 AI accountability buddy.
 *
 * Vercel serverless function (Node 18+). Expects a JSON body:
 * {
 *   "messages": [ { "role": "user" | "assistant", "content": "..." } ],
 *   "client":   { "name": "...", "lane": "Physical|Financial|Spiritual/Mental|Habitual", "goal": "..." }
 * }
 *
 * Returns: { "reply": "..." }
 *
 * The Gemini API key MUST be set as the GEMINI_API_KEY environment variable
 * in Vercel. It is never hardcoded and never sent to the browser.
 */

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.0-flash";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Lee's coaching voice, distilled into a system prompt. Grounded, warm,
// direct, no-nonsense. One goal at a time. Honest without being harsh.
// Never a therapist, never preachy, no emojis.
function buildSystemPrompt(client) {
  const name = (client && client.name) || "friend";
  const lane = (client && client.lane) || "their goal";
  const goal = (client && client.goal) || "their one goal";

  return [
    "You are the accountability buddy inside an accountability coaching app.",
    "You speak in the coach's voice: grounded, warm, direct, no-nonsense.",
    "The client you are talking to is named " + name + ".",
    "Their coaching lane is: " + lane + ".",
    "Their ONE current goal is: " + goal + ".",
    "",
    "Your job: keep them honest and moving on that ONE goal. Nothing else.",
    "",
    "Rules you never break:",
    "- Keep replies short: usually 2 to 4 sentences. One sharp question at a time.",
    "- Be honest without being harsh. Name a miss plainly, no shaming, no lectures.",
    "- Celebrate wins briefly and specifically, then point at the next step.",
    "- Always tie the conversation back to their one goal. If they drift, bring them back kindly.",
    "- Never act as a therapist, doctor, or financial advisor. If they describe a medical issue,",
    "  an injury, a mental health crisis, or ask for professional financial/legal advice,",
    "  tell them plainly to talk to a qualified professional, then refocus on what they CAN control today.",
    "- Never preachy. Never moralizing. Never emojis.",
    "- If they want to quit or skip, ask what the smallest possible version of showing up looks like today.",
    "- You do not know anything about the coach's schedule, pricing, or other clients. Do not invent it.",
  ].join("\n");
}

function toGeminiContents(systemPrompt, messages) {
  // Gemini REST format: systemInstruction + contents[] with role/parts.
  // Map our 'assistant' role to Gemini's 'model' role.
  const contents = (messages || [])
    .filter((m) => m && typeof m.content === "string" && m.content.trim().length > 0)
    .slice(-12) // keep the recent context window tight for the free tier
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content.slice(0, 2000) }],
    }));

  return {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents,
    generationConfig: {
      temperature: 0.7,
      maxOutputTokens: 300,
    },
  };
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed. Use POST." });
    return;
  }

  if (!GEMINI_API_KEY) {
    // The key lives in Vercel env vars. Never expose detail to the client.
    res.status(500).json({ error: "The buddy is not configured yet. Please try again later." });
    return;
  }

  let body = req.body;
  // Vercel usually parses JSON, but handle a raw string just in case.
  if (typeof body === "string") {
    try {
      body = JSON.parse(body);
    } catch (e) {
      res.status(400).json({ error: "Invalid request body." });
      return;
    }
  }

  const messages = body && body.messages;
  const client = body && body.client;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: "Missing messages." });
    return;
  }

  const lastUser = [...messages].reverse().find((m) => m.role === "user");
  if (!lastUser) {
    res.status(400).json({ error: "No user message found." });
    return;
  }

  const payload = toGeminiContents(buildSystemPrompt(client), messages);
  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(GEMINI_MODEL) +
    ":generateContent?key=" +
    encodeURIComponent(GEMINI_API_KEY);

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.error("Gemini error:", response.status, detail.slice(0, 500));
      res.status(502).json({ error: "The buddy is having a moment. Try again in a bit." });
      return;
    }

    const data = await response.json();
    const parts =
      data &&
      data.candidates &&
      data.candidates[0] &&
      data.candidates[0].content &&
      data.candidates[0].content.parts;

    const reply = Array.isArray(parts)
      ? parts.map((p) => p.text || "").join("").trim()
      : "";

    if (!reply) {
      res.status(502).json({ error: "The buddy came back empty. Try again." });
      return;
    }

    res.status(200).json({ reply });
  } catch (err) {
    console.error("Buddy request failed:", err && err.message);
    res.status(502).json({ error: "Could not reach the buddy. Check your connection and try again." });
  }
};
