/* Accountability Coaching app — frontend logic.
   Views: auth, onboarding, home (daily check-in), buddy, scorecards, send.
   Data: Supabase (auth + tables). AI buddy: POST /api/chat (Vercel function).
   UI copy is emoji-free. */

(function () {
  "use strict";

  // ---------------------------------------------------------------------------
  // Config + Supabase
  // ---------------------------------------------------------------------------
  var cfg = (window.APP_CONFIG || {});
  var SUPABASE_URL = cfg.SUPABASE_URL || "";
  var SUPABASE_ANON_KEY = cfg.SUPABASE_ANON_KEY || "";
  var COACH_PHONE = cfg.COACH_PHONE || "";
  var COACH_NAME = cfg.COACH_NAME || "Lee";

  var LANES = ["Physical", "Financial", "Spiritual/Mental", "Habitual"];
  var LANE_BLURBS = {
    "Physical": "Body, movement, health",
    "Financial": "Money, work, business",
    "Spiritual/Mental": "Faith, mindset, peace",
    "Habitual": "Routines, discipline, habits",
  };

  // Check-in rhythm: clients check in DAILY, Monday through Friday.
  // Monday + Friday happen over text with Lee (confirmed in-app with the
  // "I texted Lee" button). Tue / Wed / Thu use the in-app form.
  // Sat + Sun are off — no check-ins expected, never marked missed.

  var $ = function (id) { return document.getElementById(id); };

  function escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function showOnly(id) {
    document.querySelectorAll(".view").forEach(function (v) { v.classList.add("hidden"); });
    $(id).classList.remove("hidden");
    window.scrollTo(0, 0);
  }

  function setNav(view) {
    document.querySelectorAll("#bottom-nav .nav-btn").forEach(function (b) {
      b.classList.toggle("active", b.getAttribute("data-nav") === view);
    });
  }

  function showAppChrome(show) {
    $("app-header").classList.toggle("hidden", !show);
    $("bottom-nav").classList.toggle("hidden", !show);
  }

  // ---------------------------------------------------------------------------
  // Date helpers (local time, YYYY-MM-DD strings)
  // ---------------------------------------------------------------------------
  function pad(n) { return (n < 10 ? "0" : "") + n; }

  function toISODate(d) {
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }

  function parseISODate(s) {
    var p = s.split("-");
    return new Date(parseInt(p[0], 10), parseInt(p[1], 10) - 1, parseInt(p[2], 10));
  }

  function todayISO() { return toISODate(new Date()); }

  function mondayOfWeek(dateISO) {
    var d = parseISODate(dateISO);
    var dow = d.getDay(); // 0=Sun
    var diff = (dow + 6) % 7; // days since Monday
    d.setDate(d.getDate() - diff);
    return toISODate(d);
  }

  function addDays(dateISO, n) {
    var d = parseISODate(dateISO);
    d.setDate(d.getDate() + n);
    return toISODate(d);
  }

  function prettyDate(dateISO) {
    return parseISODate(dateISO).toLocaleDateString(undefined, {
      weekday: "long", month: "long", day: "numeric",
    });
  }

  function shortDate(dateISO) {
    return parseISODate(dateISO).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  }

  var DOW_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  function isOffDay(dateISO) {
    var dow = parseISODate(dateISO).getDay();
    return dow === 0 || dow === 6; // Sat, Sun — no check-ins expected
  }

  // Monday + Friday check-ins happen over text with Lee, confirmed in-app.
  function isTextDay(dateISO) {
    var dow = parseISODate(dateISO).getDay();
    return dow === 1 || dow === 5; // Mon, Fri
  }

  function dayTypeFor(dateISO) {
    var dow = parseISODate(dateISO).getDay();
    if (dow === 1) return "monday";
    if (dow === 5) return "friday";
    return "daily";
  }

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  var supabase = null;
  var user = null;
  var profile = null; // row from public.clients
  var weekCheckIns = []; // check_ins rows for the current week
  var currentView = "home";

  // ---------------------------------------------------------------------------
  // Boot
  // ---------------------------------------------------------------------------
  document.addEventListener("DOMContentLoaded", boot);

  async function boot() {
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !window.supabase) {
      showOnly("view-setup-error");
      return;
    }
    supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    wireAuth();
    wireOnboarding();
    wireHome();
    wireBuddy();
    wireScorecards();
    wireSend();
    wireChrome();

    var session = (await supabase.auth.getSession()).data.session;
    if (session && session.user) {
      user = session.user;
      await afterSignIn();
    } else {
      showAppChrome(false);
      showOnly("view-auth");
    }

    supabase.auth.onAuthStateChange(async function (event, session) {
      if (event === "SIGNED_OUT") {
        user = null; profile = null;
        showAppChrome(false);
        showOnly("view-auth");
      }
    });
  }

  async function afterSignIn() {
    var res = await supabase.from("clients").select("*").eq("id", user.id).maybeSingle();
    if (res.error) {
      showAuthError("Could not load your profile. Please try again.");
      return;
    }
    profile = res.data || null;
    showAppChrome(true);
    if (!profile) {
      startOnboarding();
    } else {
      await goHome();
    }
  }

  function wireChrome() {
    $("btn-signout").addEventListener("click", async function () {
      await supabase.auth.signOut();
    });
    document.querySelectorAll("#bottom-nav .nav-btn").forEach(function (b) {
      b.addEventListener("click", function () {
        var v = b.getAttribute("data-nav");
        if (v === "home") goHome();
        else if (v === "buddy") goBuddy();
        else if (v === "scorecards") goScorecards();
      });
    });
  }

  // ---------------------------------------------------------------------------
  // Auth
  // ---------------------------------------------------------------------------
  var authMode = "signin";

  function wireAuth() {
    document.querySelectorAll("[data-authtab]").forEach(function (t) {
      t.addEventListener("click", function () {
        authMode = t.getAttribute("data-authtab");
        document.querySelectorAll("[data-authtab]").forEach(function (x) {
          x.classList.toggle("active", x === t);
        });
        $("auth-submit").textContent = authMode === "signin" ? "Sign in" : "Create account";
        $("auth-error").classList.add("hidden");
      });
    });

    $("form-auth").addEventListener("submit", async function (e) {
      e.preventDefault();
      $("auth-error").classList.add("hidden");
      var email = $("auth-email").value.trim();
      var password = $("auth-password").value;
      $("auth-submit").disabled = true;
      try {
        if (authMode === "signin") {
          var s = await supabase.auth.signInWithPassword({ email: email, password: password });
          if (s.error) throw s.error;
          user = s.data.user;
        } else {
          var u = await supabase.auth.signUp({ email: email, password: password });
          if (u.error) throw u.error;
          user = u.data.user;
          // If email confirmation is on, there may be no session yet.
          if (!u.data.session) {
            showAuthError("Account created. Check your email to confirm, then sign in.");
            $("auth-submit").disabled = false;
            return;
          }
        }
        await afterSignIn();
      } catch (err) {
        showAuthError(err.message || "Something went wrong. Try again.");
      }
      $("auth-submit").disabled = false;
    });
  }

  function showAuthError(msg) {
    var el = $("auth-error");
    el.textContent = msg;
    el.classList.remove("hidden");
  }

  // ---------------------------------------------------------------------------
  // Onboarding — 5 steps: name, lane, goal, obstacle, win
  // ---------------------------------------------------------------------------
  var OB_STEPS = ["name", "lane", "goal", "obstacle", "win"];
  var obIndex = 0;
  var obData = { name: "", lane: "", goal: "", obstacle: "", win_looks_like: "" };

  var OB_TITLES = {
    name: "What is your name?",
    lane: "Pick your lane",
    goal: "Your ONE goal",
    obstacle: "Biggest obstacle",
    win: "What does a win look like?",
  };
  var OB_SUBS = {
    name: "What should your coach call you?",
    lane: "One lane at a time. You can change it later with your coach.",
    goal: "One goal only. Clear and specific beats big and vague.",
    obstacle: "What usually gets in the way?",
    win: "Describe what winning this week looks like in one or two sentences.",
  };

  function startOnboarding() {
    obIndex = 0;
    obData = { name: "", lane: "", goal: "", obstacle: "", win_looks_like: "" };
    setNav("home");
    showOnly("view-onboarding");
    renderOnboardingStep();
  }

  function wireOnboarding() {
    $("onboarding-back").addEventListener("click", function () {
      if (obIndex > 0) { obIndex--; renderOnboardingStep(); }
    });
    $("onboarding-next").addEventListener("click", async function () {
      $("onboarding-error").classList.add("hidden");
      if (!collectOnboardingStep()) return; // validation failed
      if (obIndex < OB_STEPS.length - 1) {
        obIndex++;
        renderOnboardingStep();
      } else {
        await finishOnboarding();
      }
    });
  }

  function renderOnboardingStep() {
    var step = OB_STEPS[obIndex];
    var dots = $("onboarding-dots");
    dots.innerHTML = "";
    OB_STEPS.forEach(function (_, i) {
      var d = document.createElement("span");
      d.className = "dot" + (i < obIndex ? " done" : i === obIndex ? " now" : "");
      dots.appendChild(d);
    });

    var html = "<h1>" + OB_TITLES[step] + "</h1><p class='muted'>" + OB_SUBS[step] + "</p>";
    if (step === "name") {
      html += '<label class="field"><input type="text" id="ob-name" maxlength="60" placeholder="Your name" value="' + escapeHtml(obData.name) + '" /></label>';
    } else if (step === "lane") {
      html += '<div class="lane-grid">';
      LANES.forEach(function (lane) {
        html += '<div class="lane-card' + (obData.lane === lane ? " selected" : "") + '" data-lane="' + lane + '">' +
          escapeHtml(lane) + "<small>" + escapeHtml(LANE_BLURBS[lane]) + "</small></div>";
      });
      html += "</div>";
    } else if (step === "goal") {
      html += '<label class="field"><textarea id="ob-goal" maxlength="500" placeholder="Example: Walk 30 minutes, 4 days this week.">' + escapeHtml(obData.goal) + "</textarea></label>";
    } else if (step === "obstacle") {
      html += '<label class="field"><textarea id="ob-obstacle" maxlength="500" placeholder="Example: I lose steam after day three.">' + escapeHtml(obData.obstacle) + "</textarea></label>";
    } else if (step === "win") {
      html += '<label class="field"><textarea id="ob-win" maxlength="500" placeholder="Example: Four walks done, no excuses, feeling stronger.">' + escapeHtml(obData.win_looks_like) + "</textarea></label>";
    }
    $("onboarding-step").innerHTML = html;
    $("onboarding-next").textContent = obIndex === OB_STEPS.length - 1 ? "Finish" : "Continue";
    $("onboarding-back").style.visibility = obIndex === 0 ? "hidden" : "visible";

    document.querySelectorAll(".lane-card").forEach(function (c) {
      c.addEventListener("click", function () {
        document.querySelectorAll(".lane-card").forEach(function (x) { x.classList.remove("selected"); });
        c.classList.add("selected");
        obData.lane = c.getAttribute("data-lane");
      });
    });

    var firstInput = $("onboarding-step").querySelector("input, textarea");
    if (firstInput) firstInput.focus();
  }

  function obError(msg) {
    var el = $("onboarding-error");
    el.textContent = msg;
    el.classList.remove("hidden");
    return false;
  }

  function collectOnboardingStep() {
    var step = OB_STEPS[obIndex];
    if (step === "name") {
      var v = $("ob-name").value.trim();
      if (!v) return obError("Please enter your name.");
      obData.name = v;
    } else if (step === "lane") {
      if (!obData.lane) return obError("Please pick a lane.");
    } else if (step === "goal") {
      var g = $("ob-goal").value.trim();
      if (!g) return obError("Please write your one goal.");
      obData.goal = g;
    } else if (step === "obstacle") {
      obData.obstacle = $("ob-obstacle").value.trim();
    } else if (step === "win") {
      obData.win_looks_like = $("ob-win").value.trim();
    }
    return true;
  }

  async function finishOnboarding() {
    $("onboarding-next").disabled = true;
    try {
      var res = await supabase.from("clients").insert({
        id: user.id,
        email: user.email,
        name: obData.name,
        lane: obData.lane,
        goal: obData.goal,
        obstacle: obData.obstacle || null,
        win_looks_like: obData.win_looks_like || null,
        start_date: todayISO(),
      });
      if (res.error) throw res.error;
      profile = (await supabase.from("clients").select("*").eq("id", user.id).single()).data;
      await goHome();
    } catch (err) {
      obError(err.message || "Could not save. Try again.");
    }
    $("onboarding-next").disabled = false;
  }

  // ---------------------------------------------------------------------------
  // Home
  // ---------------------------------------------------------------------------
  function wireHome() {
    $("btn-open-send").addEventListener("click", function () { goSend(); });
  }

  async function goHome() {
    currentView = "home";
    setNav("home");
    await refreshWeek();
    renderHome();
    showOnly("view-home");
  }

  async function refreshWeek() {
    var monday = mondayOfWeek(todayISO());
    var sunday = addDays(monday, 6);
    var res = await supabase.from("check_ins")
      .select("*")
      .eq("client_id", user.id)
      .gte("date", monday)
      .lte("date", sunday)
      .order("date", { ascending: true });
    weekCheckIns = res.error ? [] : (res.data || []);
  }

  function checkInFor(dateISO) {
    for (var i = 0; i < weekCheckIns.length; i++) {
      if (weekCheckIns[i].date === dateISO) return weekCheckIns[i];
    }
    return null;
  }

  // Status of one day in the week strip: done | text | missed | off | today | upcoming
  // "text" = Monday/Friday check-in confirmed via text with Lee.
  function dayStatus(dateISO) {
    var today = todayISO();
    if (isOffDay(dateISO)) return "off";
    if (dateISO > today) return "upcoming";
    var ci = checkInFor(dateISO);
    if (ci && ci.via_text) return "text";
    if (dateISO === today) return ci ? "done" : "today";
    return ci ? "done" : "missed";
  }

  function greetingForHour() {
    var h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
  }

  function renderHome() {
    $("home-greeting").textContent = greetingForHour() + ", " + profile.name.split(" ")[0];
    $("home-date-line").textContent = prettyDate(todayISO());
    $("home-goal").textContent = profile.goal;
    $("home-lane").textContent = profile.lane;

    // Week strip
    var monday = mondayOfWeek(todayISO());
    var strip = $("week-strip");
    strip.innerHTML = "";
    var marks = { done: "&#10003;", text: "&#10003;", missed: "X", off: "Rest", today: "&#8226;", upcoming: "" };
    var titles = {
      done: " — checked in",
      text: " — texted Lee",
      missed: " — missed",
      off: " — weekend, no check-in",
      today: " — today",
      upcoming: "",
    };
    for (var i = 0; i < 7; i++) {
      var d = addDays(monday, i);
      var st = dayStatus(d);
      var cell = document.createElement("div");
      cell.className = "day-cell " + st;
      cell.innerHTML = '<span class="dow">' + DOW_NAMES[parseISODate(d).getDay()] + "</span>" +
        '<span class="mark">' + marks[st] + "</span>";
      cell.title = shortDate(d) + titles[st];
      strip.appendChild(cell);
    }

    renderTodayCard();
  }

  function renderTodayCard() {
    var today = todayISO();
    var box = $("today-card");
    var existing = checkInFor(today);

    // Saturday + Sunday: off. No check-ins expected, never marked missed.
    if (isOffDay(today)) {
      box.innerHTML =
        '<div class="card tint-green"><h2>Weekend</h2>' +
        "<p>No check-in today. Rest up — the week starts Monday with a text to Lee.</p></div>";
      return;
    }

    // Monday + Friday: check in over text with Lee, confirm here.
    if (isTextDay(today)) {
      if (existing && existing.via_text) {
        box.innerHTML =
          '<div class="card tint-green"><h2>Checked in with Lee</h2>' +
          "<p>Text check-in confirmed for today. Nice work showing up.</p></div>";
        return;
      }
      var isFriday = parseISODate(today).getDay() === 5;
      box.innerHTML =
        '<div class="card tint-gold"><h2>Text Lee today</h2>' +
        "<p>" + (isFriday
          ? "Friday check-in happens over text. Send Lee your wins and misses for the week, then tap below."
          : "Monday check-in happens over text. Send Lee your plan for the week, then tap below.") + "</p>" +
        '<p id="textcheck-error" class="error hidden"></p>' +
        '<button type="button" id="btn-texted-lee" class="btn-primary btn-block">I texted Lee</button></div>';
      $("btn-texted-lee").addEventListener("click", confirmTextCheckIn);
      return;
    }

    // Tuesday / Wednesday / Thursday: in-app check-in form.
    if (existing) {
      box.innerHTML =
        '<div class="card tint-green"><h2>Checked in for today</h2>' +
        summaryHtml(existing) +
        '<button type="button" id="btn-edit-checkin" class="btn-secondary btn-block" style="margin-top:10px">Update check-in</button></div>';
      $("btn-edit-checkin").addEventListener("click", function () { renderCheckInForm(existing); });
      return;
    }

    renderCheckInForm(null);
  }

  // Monday/Friday: client texts Lee directly, then confirms here.
  // Friday's confirmation builds the Weekly Win Scorecard.
  async function confirmTextCheckIn() {
    var errEl = $("textcheck-error");
    errEl.classList.add("hidden");
    var today = todayISO();
    var type = dayTypeFor(today); // "monday" or "friday"
    try {
      var existing = checkInFor(today);
      var row = {
        client_id: user.id,
        date: today,
        day_type: type,
        via_text: true,
        notes: "Confirmed: texted Lee.",
      };
      var res = existing
        ? await supabase.from("check_ins").update(row).eq("id", existing.id)
        : await supabase.from("check_ins").insert(row);
      if (res.error) throw res.error;

      await refreshWeek(); // refresh BEFORE building so the scorecard includes today's confirmation
      if (type === "friday") await buildScorecard();
      renderHome();
    } catch (err) {
      errEl.textContent = err.message || "Could not save. Try again.";
      errEl.classList.remove("hidden");
    }
  }

  function summaryHtml(ci) {
    if (ci.via_text) {
      return "<p><strong>Texted Lee</strong> — confirmed via text.</p>";
    }
    var out = "";
    if (ci.plan) out += "<p><strong>Plan:</strong> " + escapeHtml(ci.plan) + "</p>";
    if (ci.wins) out += "<p><strong>Wins:</strong> " + escapeHtml(ci.wins) + "</p>";
    if (ci.misses) out += "<p><strong>Misses:</strong> " + escapeHtml(ci.misses) + "</p>";
    if (ci.notes) out += "<p><strong>Notes:</strong> " + escapeHtml(ci.notes) + "</p>";
    return out || "<p class='muted'>Checked in.</p>";
  }

  function renderCheckInForm(existing) {
    // Tuesday / Wednesday / Thursday only. Monday + Friday are text days.
    var box = $("today-card");
    var title = "Daily check-in";
    var intro = "Quick and honest. Did you move on your goal today?";
    var fields =
      fieldHtml("wins", "Wins today", existing && existing.wins, "What went right?") +
      fieldHtml("misses", "Misses today", existing && existing.misses, "What slipped?") +
      fieldHtml("notes", "Notes", existing && existing.notes, "Optional.");

    box.innerHTML =
      '<div class="card"><h2>' + title + "</h2>" +
      '<p class="muted">' + intro + "</p>" +
      '<form id="checkin-form">' + fields +
      '<p id="checkin-error" class="error hidden"></p>' +
      '<button type="submit" class="btn-primary btn-block">' +
      (existing ? "Update check-in" : "Submit check-in") + "</button></form></div>";

    $("checkin-form").addEventListener("submit", async function (e) {
      e.preventDefault();
      await submitCheckIn(existing);
    });
  }

  function fieldHtml(name, label, value, placeholder) {
    return '<label class="field"><span>' + escapeHtml(label) + "</span>" +
      '<textarea id="ci-' + name + '" maxlength="1000" placeholder="' + escapeHtml(placeholder) + '">' +
      escapeHtml(value || "") + "</textarea></label>";
  }

  function val(id) {
    var el = $(id);
    return el ? el.value.trim() : "";
  }

  async function submitCheckIn(existing) {
    var errEl = $("checkin-error");
    errEl.classList.add("hidden");
    var today = todayISO();
    var row = {
      client_id: user.id,
      date: today,
      day_type: "daily", // Tue / Wed / Thu — Mon + Fri are text days
      wins: val("ci-wins") || null,
      misses: val("ci-misses") || null,
      notes: val("ci-notes") || null,
    };

    try {
      var res;
      if (existing) {
        res = await supabase.from("check_ins").update(row).eq("id", existing.id);
      } else {
        res = await supabase.from("check_ins").insert(row);
      }
      if (res.error) throw res.error;

      await refreshWeek();
      renderHome();
    } catch (err) {
      errEl.textContent = err.message || "Could not save. Try again.";
      errEl.classList.remove("hidden");
    }
  }

  // ---------------------------------------------------------------------------
  // Scorecards
  // ---------------------------------------------------------------------------
  function wireScorecards() {}

  async function buildScorecard() {
    var monday = mondayOfWeek(todayISO());
    var expected = [];
    for (var i = 0; i < 7; i++) {
      var d = addDays(monday, i);
      if (!isOffDay(d)) expected.push(d);
    }
    var done = weekCheckIns.filter(function (c) { return c.date >= monday; });
    var wins = [], misses = [];
    done.forEach(function (c) {
      if (c.wins) wins.push({ date: c.date, text: c.wins });
      if (c.misses) misses.push({ date: c.date, text: c.misses });
    });
    var mondayRow = checkInFor(monday);

    var summary = {
      week_start: monday,
      goal: profile.goal,
      lane: profile.lane,
      plan: mondayRow ? mondayRow.plan : null,
      expected_days: expected.length,
      completed_days: done.length,
      check_ins: done.map(function (c) {
        return { date: c.date, day_type: c.day_type, via_text: !!c.via_text, plan: c.plan, wins: c.wins, misses: c.misses, notes: c.notes };
      }),
      wins: wins,
      misses: misses,
    };

    await supabase.from("scorecards").upsert(
      { client_id: user.id, week_start: monday, summary: summary },
      { onConflict: "client_id,week_start" }
    );
  }

  async function goScorecards() {
    currentView = "scorecards";
    setNav("scorecards");
    showOnly("view-scorecards");
    var list = $("scorecard-list");
    list.innerHTML = "<p class='muted'>Loading...</p>";
    var res = await supabase.from("scorecards")
      .select("*")
      .eq("client_id", user.id)
      .order("week_start", { ascending: false });
    if (res.error || !res.data || res.data.length === 0) {
      list.innerHTML = '<div class="card"><p class="muted">No scorecards yet. Your first one is built from your Friday check-in.</p></div>';
      return;
    }
    list.innerHTML = "";
    res.data.forEach(function (sc) {
      var s = sc.summary || {};
      var card = document.createElement("div");
      card.className = "card scorecard";
      var html = '<div class="scorecard-head"><h2>Week of ' + escapeHtml(shortDate(s.week_start || sc.week_start)) + "</h2>" +
        "<strong>" + (s.completed_days || 0) + "/" + (s.expected_days || 5) + " check-ins</strong></div>";
      html += '<div class="score-row"><span>Goal</span><span>' + escapeHtml(s.goal || "") + "</span></div>";
      html += '<div class="score-row"><span>Lane</span><span>' + escapeHtml(s.lane || "") + "</span></div>";
      if (s.plan) html += '<div class="score-row"><span>Monday plan</span><span>' + escapeHtml(s.plan) + "</span></div>";
      var wins = (s.wins || []).map(function (w) { return escapeHtml(w.text); }).join("; ");
      var misses = (s.misses || []).map(function (m) { return escapeHtml(m.text); }).join("; ");
      if (wins) html += '<div class="score-row"><span>Wins</span><span>' + wins + "</span></div>";
      if (misses) html += '<div class="score-row"><span>Misses</span><span>' + misses + "</span></div>";
      card.innerHTML = html;
      list.appendChild(card);
    });
  }

  // ---------------------------------------------------------------------------
  // AI Buddy
  // ---------------------------------------------------------------------------
  function wireBuddy() {
    $("buddy-form").addEventListener("submit", async function (e) {
      e.preventDefault();
      var input = $("buddy-input");
      var text = input.value.trim();
      if (!text) return;
      input.value = "";
      await sendBuddyMessage(text);
    });
  }

  async function goBuddy() {
    currentView = "buddy";
    setNav("buddy");
    showOnly("view-buddy");
    await loadBuddyHistory();
  }

  async function loadBuddyHistory() {
    var box = $("buddy-messages");
    box.innerHTML = "<p class='muted'>Loading...</p>";
    var res = await supabase.from("buddy_messages")
      .select("*")
      .eq("client_id", user.id)
      .order("created_at", { ascending: true })
      .limit(60);
    box.innerHTML = "";
    var rows = res.error ? [] : (res.data || []);
    if (rows.length === 0) {
      appendBuddyMsg("assistant", "Hey " + profile.name.split(" ")[0] + ". I am your accountability buddy — here any time you need a straight answer or a push. Your one goal right now: " + profile.goal + ". What is on your mind?");
      return;
    }
    rows.forEach(function (r) { appendBuddyMsg(r.role, r.content); });
    box.scrollTop = box.scrollHeight;
  }

  function appendBuddyMsg(role, content) {
    var box = $("buddy-messages");
    var div = document.createElement("div");
    div.className = "msg " + (role === "user" ? "user" : "assistant");
    div.textContent = content;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
    return div;
  }

  async function sendBuddyMessage(text) {
    var typing = appendBuddyMsg("assistant", "Thinking...");
    typing.classList.add("typing");

    try {
      await supabase.from("buddy_messages").insert({ client_id: user.id, role: "user", content: text });

      var hist = await supabase.from("buddy_messages")
        .select("role, content")
        .eq("client_id", user.id)
        .order("created_at", { ascending: false })
        .limit(12);
      var messages = (hist.data || []).reverse();

      var resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: messages,
          client: { name: profile.name, lane: profile.lane, goal: profile.goal },
        }),
      });
      var data = await resp.json().catch(function () { return {}; });
      if (!resp.ok) throw new Error(data.error || "Buddy request failed.");

      typing.remove();
      appendBuddyMsg("assistant", data.reply);
      await supabase.from("buddy_messages").insert({ client_id: user.id, role: "assistant", content: data.reply });
    } catch (err) {
      typing.remove();
      appendBuddyMsg("assistant", "I hit a snag. Give me a minute and try again.");
      console.error(err);
    }
  }

  // ---------------------------------------------------------------------------
  // Send to Lee
  // ---------------------------------------------------------------------------
  function wireSend() {
    $("btn-send-back").addEventListener("click", function () { goHome(); });
    $("btn-send-copy").addEventListener("click", async function () {
      var text = buildSendText();
      try {
        await navigator.clipboard.writeText(text);
        $("btn-send-copy").textContent = "Copied. Paste it into a text to Lee.";
        setTimeout(function () { $("btn-send-copy").textContent = "Copy the text instead"; }, 2500);
      } catch (e) {
        $("btn-send-copy").textContent = "Copy failed — select the text above manually.";
      }
    });
    $("btn-send-sms").addEventListener("click", function () {
      var text = buildSendText();
      if (COACH_PHONE) {
        window.location.href = "sms:" + encodeURIComponent(COACH_PHONE) + "?body=" + encodeURIComponent(text);
      } else if (navigator.share) {
        navigator.share({ title: "Weekly update", text: text }).catch(function () {});
      } else {
        $("btn-send-sms").textContent = "Coach number not set — use Copy instead.";
      }
    });
  }

  function goSend() {
    currentView = "send";
    setNav("home");
    $("send-preview").textContent = buildSendText();
    showOnly("view-send");
  }

  function buildSendText() {
    var monday = mondayOfWeek(todayISO());
    var lines = [];
    lines.push("Weekly update for " + COACH_NAME);
    lines.push(profile.name + " — " + profile.lane + " lane");
    lines.push("Week of " + shortDate(monday));
    lines.push("Goal: " + profile.goal);
    lines.push("");

    var ordered = weekCheckIns.slice().sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    var doneCount = 0;
    var missedDays = [];
    for (var i = 0; i < 7; i++) {
      var d = addDays(monday, i);
      if (isOffDay(d)) continue;
      var ci = checkInFor(d);
      var label = DOW_NAMES[parseISODate(d).getDay()];
      if (ci) {
        doneCount++;
        var bits = [];
        if (ci.via_text) {
          bits.push("Texted Lee (confirmed)");
        } else {
          if (ci.plan) bits.push("Plan: " + ci.plan);
          if (ci.wins) bits.push("Wins: " + ci.wins);
          if (ci.misses) bits.push("Misses: " + ci.misses);
          if (ci.notes && ci.notes !== "Confirmed: texted Lee.") bits.push("Notes: " + ci.notes);
        }
        lines.push(label + ": " + (bits.join(" | ") || "checked in"));
      } else if (d < todayISO()) {
        missedDays.push(label);
        lines.push(label + ": X (missed)");
      } else if (d === todayISO()) {
        lines.push(label + ": checking in now");
      }
    }
    lines.push("");
    lines.push("Check-ins: " + doneCount + "/5 complete");
    if (missedDays.length) lines.push("Missed: " + missedDays.join(", "));
    return lines.join("\n");
  }

})();

