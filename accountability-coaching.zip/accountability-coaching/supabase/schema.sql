-- Accountability Coaching app — Supabase schema
-- Run this in the Supabase SQL Editor (one paste, one run).
-- All tables are client-scoped: Row Level Security makes sure a signed-in
-- client can only ever read/write their OWN rows.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- clients: one row per coaching client. id matches the auth.users id.
-- Lee onboards each client; the app's onboarding flow writes this row.
-- ---------------------------------------------------------------------------
create table if not exists public.clients (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  name text not null,
  lane text not null check (lane in ('Physical', 'Financial', 'Spiritual/Mental', 'Habitual')),
  goal text not null,
  obstacle text,
  win_looks_like text,
  start_date date not null default current_date,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- check_ins: one row per client per day.
-- day_type: 'monday' / 'friday' (check-in happens over TEXT with Lee, then
--           confirmed in-app), 'daily' (Tue / Wed / Thu in-app check-in form).
-- via_text: true when a Monday/Friday check-in was confirmed via text.
-- Sat + Sun are off — no check-ins expected, never marked missed, no rows.
-- ---------------------------------------------------------------------------
create table if not exists public.check_ins (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients (id) on delete cascade,
  date date not null,
  day_type text not null check (day_type in ('monday', 'daily', 'friday')),
  via_text boolean not null default false,
  plan text,
  wins text,
  misses text,
  notes text,
  created_at timestamptz not null default now(),
  unique (client_id, date)
);

-- For databases created before the via_text flag existed:
alter table public.check_ins add column if not exists via_text boolean not null default false;

-- ---------------------------------------------------------------------------
-- scorecards: one per client per week, built from the Friday check-in.
-- summary is a JSON snapshot: { week_start, goal, lane, check_ins, wins,
-- misses, completed_days, expected_days }.
-- ---------------------------------------------------------------------------
create table if not exists public.scorecards (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients (id) on delete cascade,
  week_start date not null,
  summary jsonb not null,
  created_at timestamptz not null default now(),
  unique (client_id, week_start)
);

-- ---------------------------------------------------------------------------
-- buddy_messages: the 24/7 AI accountability buddy conversation history.
-- ---------------------------------------------------------------------------
create table if not exists public.buddy_messages (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients (id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz not null default now()
);

-- Index for the buddy chat history (newest last, fast per-client reads).
create index if not exists buddy_messages_client_created_idx
  on public.buddy_messages (client_id, created_at);

-- Index for weekly check-in lookups.
create index if not exists check_ins_client_date_idx
  on public.check_ins (client_id, date);

-- ---------------------------------------------------------------------------
-- Row Level Security: clients only see their own rows. No exceptions.
-- ---------------------------------------------------------------------------
alter table public.clients enable row level security;
alter table public.check_ins enable row level security;
alter table public.scorecards enable row level security;
alter table public.buddy_messages enable row level security;

-- clients: a signed-in user manages only the row whose id is their own.
drop policy if exists "clients_self" on public.clients;
create policy "clients_self" on public.clients
  for all
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- check_ins: scoped to the client's own rows.
drop policy if exists "check_ins_self" on public.check_ins;
create policy "check_ins_self" on public.check_ins
  for all
  using (auth.uid() = client_id)
  with check (auth.uid() = client_id);

-- scorecards: scoped to the client's own rows.
drop policy if exists "scorecards_self" on public.scorecards;
create policy "scorecards_self" on public.scorecards
  for all
  using (auth.uid() = client_id)
  with check (auth.uid() = client_id);

-- buddy_messages: scoped to the client's own rows.
drop policy if exists "buddy_messages_self" on public.buddy_messages;
create policy "buddy_messages_self" on public.buddy_messages
  for all
  using (auth.uid() = client_id)
  with check (auth.uid() = client_id);
